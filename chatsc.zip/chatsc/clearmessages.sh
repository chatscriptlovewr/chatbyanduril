#!/bin/bash

rm -f messages.txt
touch messages.txt

echo "Messages are cleaned"
