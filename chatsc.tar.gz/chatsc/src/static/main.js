const socket = io();
const messageList = document.getElementById('message-list');
const chatForm = document.getElementById('chat-form');
const messageInput = document.getElementById('message-input');
let name;
let permission;
if (localStorage.getItem("permission") == "true") permission = true;
else {
  permission = false
}
const title = "EMBED SOHBET"
const msgtitle = "(!) New Message"
document.addEventListener("visibilitychange", (event) => {
  console.dir(event)
});

chatForm.addEventListener('submit', e => {
  e.preventDefault();
  const message = "[" + new Date().toLocaleString("tr-TR") + " " + name + "] " + messageInput.value;
  if (messageInput.value.trim() !== '') {
    socket.emit('chat message', message);
    messageInput.value = '';
    // Save message to file
    fetch('/', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        message: message
      })
    }).then(response => {
      if (!response.ok) {
        throw new Error('Network response was not ok');
      }
      console.log('Message saved');
    }).catch(error => {
      console.error('Error saving message:', error);
    });
  }
});

socket.on('chat message', message => {
  const li = document.createElement('li');
  li.textContent = message;
  li.style.fontSize = "18px";
  messageList.appendChild(li);
  if (permission = true && message.indexOf(name) == -1) {
    let notif = new Notification("Rednexie Chat | Yeni mesaj", {
      body: message,
      /*badge: "https://example.com/badge.png",
        icon: "https://example.com/icon.png",
        // Set the actions array
        actions: [
          // First action
          {
            action: "like",
            title: "Like",
            icon: "https://example.com/like.png"
          },
          // Second action
          {
            action: "dismiss",
            title: "Dismiss",
            icon: "https://example.com/dismiss.png"
          }
        ]*/


    });
  }

  if (document.hasFocus() == false) {
    document.title = msgtitle;
  }
});

window.addEventListener("load", () => {
  if (typeof localStorage.getItem("name") == "string") {
    name = localStorage.getItem("name");
    fetch("/user/login/" + localStorage.getItem("name"));
    alert("Hoşgeldiniz, [" + name + "].")
    if (Notification) {
      if (localStorage.getItem("permission") == "true") return
      if (localStorage.getItem("permission") == "false") return
      Notification.requestPermission().then((perm) => {
        if (perm == "granted") {
          localStorage.setItem("permission", "true");
          permission = true
          return
        }
        else {
          permission = false
          localStorage.setItem("permission", "false")
        }
      })
    }
    return
  }

  for (let i = 0; i < 100; i++) {
    if (name && name != null && name != "") {
      localStorage.setItem("name", name)
      console.log(name)
      fetch("/user/login/" + localStorage.getItem("name"))
      return
    }
    name = prompt("Lütfen isminizi giriniz.");
  }


})

window.addEventListener("focus", (event) => {
  document.title = title;
})