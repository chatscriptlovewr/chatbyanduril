const fs = require("fs");
const fix = `|--------------------------------------------------------------------------------------------------------------------|\n|                                                                                                                    |\n|                                                                                                                    |
|--------------------------------------------------------------------------------------------------------------------|\n`

const fetch = require("node-fetch");
const consoled = require("consoled.js")

function webhook(text, url) {
  try {
    new URL(url);
  }
  catch (err) {
    consoled.bright.bgred("The second argument should be a valid url")
    return false;
  }



  var params = {
    content: text,
    username: "Anduril-Logs",
    avatar_url: "https://cdn.discordapp.com/attachments/1068642023789301884/1091345356173889660/st_small_507x507-pad_600x600_f8f8f8-removebg.png",
  }


  fetch(url, {
    method: "POST",
    headers: {
      'Content-type': 'application/json'
    },
    body: JSON.stringify(params),
  }).then(res => {
    // console.log(res);
    if (!String(res.status).includes("20")) {
      consoled.bright.red("Error with the webhook: " + res.status + " " + res.statusText)
    }
  })
}

module.exports.webhook = webhook;



function log(text) {
  const filePath = './../logs.txt';

  fs.access(filePath, (err) => {
    if (err) {
      // File doesn't exist, create new file and append data
      fs.writeFile(filePath, fix + text, (err) => {
        if (err) throw err;
      });
    } else {
      // File exists, append data to existing file
      fs.appendFile(filePath, text, (err) => {
        if (err) throw err;
      });
    }
  });

}

function clear() {
  fs.unlink('./../../log.txt', (err) => {
    if (err) {
      console.log('\x1b[31m%s\x1b[0m', `Error deleting file: \n${err.message}`);
      return;
    }
    console.log('\x1b[32m%s\x1b[0m', 'File deleted successfully');
  });
}


function empty() {

  if (fs.existsSync(filePath)) {
    // Open file in write mode, this will truncate (empty) the file
    fs.writeFile(filePath, '', err => {
      if (err) {
        // Log red error message if there was an error
        console.error('\x1b[1;31mError emptying file:\x1b[0m', err);
      } else {
        // Log green success message if file was emptied successfully
        console.log('\x1b[32mFile emptied successfully.\x1b[0m');
      }
    });
  } else {
    console.log('\x1b[31mFile does not exist, skipping.\x1b[0m');
  }

}



module.exports = log;
module.exports.empty = empty;
module.exports.clear = clear;
module.exports.webhook = webhook;