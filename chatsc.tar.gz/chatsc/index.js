const express = require('express');
const app = express();
const server = require('http').createServer(app);
const io = require('socket.io')(server);
const consoled = require("consoled.js")
const log = require("./src/modules/log");
const bodyParser = require("body-parser");
const fs = require("fs");
const cache = require("./src/modules/lcache.js")
const serverPort = 80;
const st = new Date().toLocaleString("tr-TR");
app.set("view engine", "ejs")


app.use((req, res, next) => {
  const ipp = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const ip = ipp.replace("::ffff:", "-local-")
  const uas = req.headers['user-agent']
  const method = req.method;
  const url = req.hostname + req.path;
  const time = new Date().toLocaleString("tr-TR");
  const requestPath = req.path;
  consoled.bright.green(`[${method}] [${time}] IP: ${ip} | URL: ${url} | Path: ${requestPath} | Method: ${method}`)
  log(`\n[New Request] [${time}] IP: ${ip} | URL: ${url} | Path: ${requestPath} | Method: ${method}`)

  next();
});






app.use(bodyParser.json());



app.use(express.static("src/static"))


io.on('connection', socket => {
  console.log('A user connected');

  socket.on('disconnect', () => {
    console.log('A user disconnected');
  });

  socket.on('chat message', msg => {
    io.emit('chat message', msg);
  });
});

app.post('/', (req, res) => {
  const message = req.body.message;
  console.log('Received message:', message);
  // Append message to text file
  fs.appendFile('messages.txt', message + '\n', (err) => {
    if (err) {
      console.error('Error saving message to file:', err);
    } else {
      //console.log('Message saved to file');
    }
  });
  res.send('Message received');
});

app.get('/msgs', (req, res) => {
  fs.readFile('messages.txt', 'utf8', (err, data) => {
    if (err) {
      console.error('Error reading messages from file:', err);
      res.send('Error reading messages from file');
    } else {
      const messages = data.split('\n');
      res.send(messages);
    }
  });
});
app.get('/', (req, res) => {
  fs.readFile('messages.txt', 'utf8', (err, data) => {
    if (err) {
      console.error(err);
      return res.sendStatus(500);
    }
    const messageArr = data.trim().split('\n');
    res.render('messages.ejs', { messages: messageArr });
  });
});


app.get("/user/login/:id", (req, res) => {
  const ipp = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
  const ip = ipp.replace("::ffff:", "-local-")
  const user = req.params.id;
  if (!user || user == null || user.trim() == "") return;
  consoled.fade.cyan(`New User Logged In: ${user} with the ip address ${ip}`)
})

app.get("/cache", (req, res) => {
  let messageArr;
  if (cache.get("messages") && cache.get("messages") != null) {
    messageArr = cache.object.get("messages")
  }
  else {
    messageArr = [];
  }
  res.render('cache.ejs', { messages: messageArr, st: st });
})

app.post("/cache", (req, res) => {
  const message = req.body.message;
  let messages;
  if (!message || message == null || message.trim() == "") return;
  if (cache.get("messages") && cache.get("messages") != null) {
    messages = cache.object.get("messages");
  }
  else {
    messages = []
  }
  messages.push(message);
  cache.object.set("messages", messages);
  console.log("Message saved to cache, and will be deleted once the server is closed.");

})


const listener = server.listen(serverPort, () => {
  consoled.bright.green("Listening on port: " + listener.address().port)
})